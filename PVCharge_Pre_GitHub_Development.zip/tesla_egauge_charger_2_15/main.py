
import os
import sys
import math
from time import sleep
from dotenv import load_dotenv
from egauge import webapi

from routines import ChargeRate, TeslaCommand, MqttMsg

load_dotenv()
meter_dev = os.getenv("EGDEV")
meter_user = os.getenv("EGUSR")
meter_password = os.getenv("EGPWD")
mqtt_topic_status = os.getenv("TOPIC_STATUS")
mqtt_topic_charge_rate = os.getenv("TOPIC_CHARGE_RATE")

SLOW_POLLING = 30
SLOW_POLLING_CHK = 5
FAST_POLLING = 1
MIN_CHARGE = 7
PREVENT_NON_SOLAR_CHARGE = True

# Initialize classes
Charge_Loop = ChargeRate()
Car = TeslaCommand()
Message = MqttMsg()

# Initialize eGauge
my_egauge = webapi.device.Device(meter_dev, webapi.JWTAuth(meter_user, meter_password))

# verify we can talk to the meter:
try:
    rights = my_egauge.get("/auth/rights").get("rights", [])
except webapi.Error as e:
    print(f"Sorry, failed to connect to {meter_dev}: {e}")
    sys.exit(1)
print(f"Connected to eGauge {meter_dev} (user {meter_user}, rights={rights})")


# Function check
""""
#Car.test_cmd()
new_charge_rate = round(Charge_Loop.calculate_charge_rate(new_sample=True))
print(f"New charge rate: {new_charge_rate}")
test = Message.calculate_charge_tesla()
print(test)

if Charge_Loop.sufficient_generation(MIN_CHARGE):
    print("Sufficient")
    #str(new_charge_rate)
client.publish("garagepi/new_charge_rate", "Test1", 1)
client.publish("garagepi/new_charge_rate", "Test2", 1)
print("Messages:")
# Mqtt initialization
mqtt_queue = Queue()
while not mqtt_queue.empty():
    print(mqtt_queue.get())

Car.wake()
Car.set_charge_rate(MIN_CHARGE)
sleep(5)
Car.start_charging()
sleep(10)
print("Started?")
sleep(5)
Car.set_charge_rate(10)
sleep(10)
Car.stop_charging()
exit()
"""

# Loop variables
charge_tesla = True
car_is_charging = False
report_due_fast = 0
report_due_slow = 0
report_delay_fast = round((60 / (FAST_POLLING + 1.5)))
report_delay_slow = round((60 / SLOW_POLLING))
start_charging_count = 0
stop_charging_count = 0
while True:
    # Check if we are allowed to charge
    charge_tesla = Message.calculate_charge_tesla()    # Directly use Teslamate variables
    #charge_tesla = Message.var_topic_control    # Rely on HA to tell us when to charge (using Teslamate variables)
    #print("New command, charge: " + str(charge_tesla))

    if not charge_tesla:
        for poll in range(0, SLOW_POLLING, SLOW_POLLING_CHK):   # While waiting ensure that the car isn't charging
            if PREVENT_NON_SOLAR_CHARGE:
                print("Sample, wait")
                Charge_Loop.sample_sensor()
                if round(Charge_Loop.charge_rate_sensor) >= MIN_CHARGE:
                    Car.stop_charging()     # Stop if it is charging
            sleep(SLOW_POLLING_CHK)
        if report_due_slow >= report_delay_slow:    # Print a report roughly every minute
            status = Charge_Loop.status_report(charge_tesla, car_is_charging, new_sample=True)
            print(status)
            Message.client.publish(topic=mqtt_topic_status, payload=status, qos=1)
            report_due_slow = 0
        report_due_slow += 1

    if charge_tesla:    # If we are allowed to charge
        if car_is_charging:    # Is the car currently charging?
            if Charge_Loop.sufficient_generation(MIN_CHARGE):
                # Reset stop counter
                stop_charging_count = 0
                # Calculate new charge rate
                # Use math.floor() on calculate_charge_rate to ensure we are always just "under" the available PV generation capacity
                # Use round() on charge_rate_sensor to prevent constant requests when on the edge of a value
                new_charge_rate = math.floor(Charge_Loop.calculate_charge_rate(new_sample=False))
                print("Calculated charge rate: ", new_charge_rate)
                print("Current rate: ", round(Charge_Loop.charge_rate_sensor))
                if new_charge_rate != round(Charge_Loop.charge_rate_sensor):
                    # Set new charge rate
                    if Car.set_charge_rate(new_charge_rate):
                        if Charge_Loop.verify_new_charge_rate(new_charge_rate):
                            print("New charge rate confirmed: ", new_charge_rate)
                            Message.client.publish(topic=mqtt_topic_charge_rate, payload=new_charge_rate, qos=1)

            else:    # We don't have enough sun
                if round(Charge_Loop.charge_rate_sensor) > MIN_CHARGE:    # If we are charging at anything greater than min charge
                    # Set charge rate to min charge
                    if Car.set_charge_rate(MIN_CHARGE):
                        if Charge_Loop.verify_new_charge_rate(MIN_CHARGE):
                            print("New charge rate confirmed: ", MIN_CHARGE)
                            Message.client.publish(topic=mqtt_topic_charge_rate, payload=MIN_CHARGE, qos=1)
                else:    # We are already at min charge, begin stopping sequence
                    stop_charging_count += 1
                    print("Do we need to stop? ", stop_charging_count)
                    if stop_charging_count >= 15:
                        print("Need to stop charging")
                        if Car.stop_charging():
                            car_is_charging = False
                            stop_charging_count = 0

        else:    # Car isn't charging, should it be?
            if Charge_Loop.sufficient_generation(MIN_CHARGE):    # If we have enough sun to charge
                if round(Charge_Loop.charge_rate_sensor) < MIN_CHARGE:	   # Make sure car isn’t already charging
                    start_charging_count += 1
                    print("Do we start? ", start_charging_count)
                    if start_charging_count >= 7:
                        print("Waking car")
                        if Car.wake():
                            sleep(5)
                            print("Start charging")
                            if Car.start_charging():
                                # Wait until charging is fully started
                                sleep(10)
                                if Charge_Loop.verify_new_charge_rate(MIN_CHARGE):
                                    car_is_charging = True
                                    start_charging_count = 0
                                    # Optionally we could set a new charge rate here
                else:    # Car is already charging, set the flag
                    car_is_charging = True
                    start_charging_count = 0

            else:    # Sun isn't generating enough power to charge
                if PREVENT_NON_SOLAR_CHARGE:    # If true, prevent after-hours charging
                    Charge_Loop.sample_sensor()
                    if round(Charge_Loop.charge_rate_sensor) >= MIN_CHARGE:
                        Car.stop_charging()  # Stop if it is charging

    else:    # We aren't allowed to charge
        if car_is_charging:
            print("Need to stop charging")
            if Car.stop_charging():
                car_is_charging = False

    if report_due_fast >= report_delay_fast:    # Print a report roughly every minute
        status = Charge_Loop.status_report(charge_tesla, car_is_charging, new_sample=True)
        print(status)
        Message.client.publish(topic=mqtt_topic_status, payload=status, qos=1)
        report_due_fast = 0
    report_due_fast += 1

    # Main loop delay
    sleep(FAST_POLLING)
