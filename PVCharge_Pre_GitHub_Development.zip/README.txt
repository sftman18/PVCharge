I wrote PVCharge (originally tesla_egauge_charger) using PyCharm without uploading to GitHub.
I only thought about GitHub once I had a program I thought was worthy of sharing with others.

Included are several directory backups that I made periodically during initial development, incase I needed to revert to a previously used method.

3/11/24
sftman18