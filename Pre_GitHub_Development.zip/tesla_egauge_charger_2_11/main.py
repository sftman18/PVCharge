
import os
import sys
from time import sleep
from collections import deque
from queue import Queue
from dotenv import load_dotenv
import paho.mqtt.client as mqtt
from egauge import webapi

from routines import ChargeRate, TeslaCommand

load_dotenv()
meter_dev = os.getenv("EGDEV")
meter_user = os.getenv("EGUSR")
meter_password = os.getenv("EGPWD")
mqtt_broker = os.getenv("BROKER")
mqtt_port = int(os.getenv("PORT"))
mqtt_client_id = os.getenv("CLIENT_ID")
mqtt_topic_control = os.getenv("TOPIC_CONTROL")
mqtt_topic_status = os.getenv("TOPIC_STATUS")
mqtt_topic_charge_rate = os.getenv("TOPIC_CHARGE_RATE")

SLOW_POLLING = 30
SLOW_POLLING_CHK = 5
FAST_POLLING = 1

# At a 1sec sample rate this covers 5min
#SampleHistory = deque(maxlen=300)
GenHistory = deque(maxlen=300)
UseHistory = deque(maxlen=300)
ChgRateHistory = deque(maxlen=300)
# Queue code
#    ret = Register(test_common.dev, {"rate": "", "time": "now"})
#    GenHistory.append(round(ret.pq_rate("gen").value * 1000))

# Initialize classes
Charge_Loop = ChargeRate()
Car = TeslaCommand()

# Initialize eGauge
my_egauge = webapi.device.Device(meter_dev, webapi.JWTAuth(meter_user, meter_password))

# verify we can talk to the meter:
try:
    rights = my_egauge.get("/auth/rights").get("rights", [])
except webapi.Error as e:
    print(f"Sorry, failed to connect to {meter_dev}: {e}")
    sys.exit(1)
print(f"Connected to eGauge {meter_dev} (user {meter_user}, rights={rights})")


# MQTT subroutines
def on_connect(client, userdata, flags, rc):
    if rc != 0:
        print("Failed to connect, return code %d\n", rc)
        sys.exit(1)
    client.subscribe(topic=mqtt_topic_control, qos=1)


def on_message(client, userdata, msg):
    if msg.payload.decode("utf-8") == "True":
        #print("Charge is True")
        mqtt_queue.put(True)
    else:   # All messages not matching "True" mapped to "False"
        #print("Charge is False")
        mqtt_queue.put(False)


# Mqtt initialization
mqtt_queue = Queue()
client = mqtt.Client(client_id=mqtt_client_id, protocol=mqtt.MQTTv311, clean_session=True)
client.on_connect = on_connect
client.on_message = on_message
client.connect(mqtt_broker, mqtt_port, 60)

"""
# Function check
Car.test_cmd()
new_charge_rate = round(Charge_Loop.calculate_charge_rate(new_sample=True))
print(f"New charge rate: {new_charge_rate}")

if Charge_Loop.sufficient_generation():
    print("Sufficient")
    #str(new_charge_rate)
client.publish("garagepi/new_charge_rate", "Test1", 1)
client.publish("garagepi/new_charge_rate", "Test2", 1)
print("Messages:")
while not mqtt_queue.empty():
    print(mqtt_queue.get())

Car.wake()
Car.set_charge_rate(7)
sleep(5)
Car.start_charging()
sleep(10)
print("Started?")
sleep(5)
Car.set_charge_rate(10)
sleep(10)
Car.stop_charging()
exit()
"""


charge_tesla = True
car_is_charging = False
report_due = 0
start_charging_count = 0
stop_charging_count = 0
while True:
    client.loop()       # Connect to MQTT to process messages
    if not mqtt_queue.empty():      # Check queue for messages
        charge_tesla = mqtt_queue.get()
        print("New command, charge: " + str(charge_tesla))

    if not charge_tesla:
        for poll in range(0, SLOW_POLLING, SLOW_POLLING_CHK):   # While waiting ensure that the car isn't charging
            #print("Sample, wait")
            Charge_Loop.sample_sensor()
            if Charge_Loop.charge_rate_sensor > 5:
                Car.stop_charging()     # Stop if it is charging
            sleep(SLOW_POLLING_CHK)

    if charge_tesla:        # If we are allowed to charge
        if car_is_charging:        # Is the car currently charging?
            if Charge_Loop.sufficient_generation():
                # Calculate new charge rate
                new_charge_rate = round(Charge_Loop.calculate_charge_rate(new_sample=False))
                print("Calculated charge rate: ", new_charge_rate)
                if new_charge_rate != round(Charge_Loop.charge_rate_sensor):
                    # Set new charge rate
                    if Car.set_charge_rate(new_charge_rate):
                        if Charge_Loop.verify_new_charge_rate(new_charge_rate):
                            print("New charge rate confirmed: ", new_charge_rate)
                            client.publish(mqtt_topic_charge_rate, new_charge_rate)

            else:       # We don't have enough sun
                stop_charging_count += 1
                print("Do we need to stop? ", stop_charging_count)
                if stop_charging_count == 4:
                    print("Need to stop charging")
                    if Car.stop_charging():
                        car_is_charging = False
                        stop_charging_count = 0

        else:       # Car isn't charging, should it be?
            if Charge_Loop.sufficient_generation():
                start_charging_count += 1
                print("Do we start? ", start_charging_count)
                if start_charging_count == 4:
                    print("Waking car")
                    if Car.wake():
                        sleep(5)
                        print("Start charging")
                        if Car.start_charging():
                            # Wait until charging is fully started
                            sleep(10)
                            if Charge_Loop.verify_new_charge_rate(7):
                                car_is_charging = True
                                start_charging_count = 0
                                # Optionally we could set a new charge rate here

    else:       # We aren't allowed to charge
        if car_is_charging:
            print("Need to stop charging")
            if Car.stop_charging():
                car_is_charging = False

    # Build status string
    status = "Status: "
    if charge_tesla:
        status += "En:1 "
    else:
        status += "En:0 "
    if car_is_charging:
        status += "Chg:1 "
    else:
        status += "Chg:0 "
    status += "Cur:" + str(round(Charge_Loop.charge_rate_sensor)) + " " + "New:" + str(round(Charge_Loop.new_charge_rate))
    #client.publish(mqtt_topic_status, status)
    print(status)
    ChgRateHistory.append(Charge_Loop.new_charge_rate)
    if report_due >= 60:
        num_chg = 0
        for samp in ChgRateHistory:
            if samp >= 7:
                num_chg += 1
        print("Num avail charge: ", num_chg)
        client.publish(mqtt_topic_status, status)
        report_due = 0
    report_due += 1

    # Main loop delay
    sleep(FAST_POLLING)
