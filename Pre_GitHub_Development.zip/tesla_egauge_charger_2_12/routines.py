import os
import subprocess
import datetime
import math
from time import sleep
from dotenv import load_dotenv
from egauge.webapi.device import Register, Local, PhysicalQuantity, UnitSystem

load_dotenv()
tesla_control_bin = os.getenv("TESLA_CONTROL_BIN")
tesla_key_file = os.getenv("TESLA_KEY_FILE")


class ChargeRate:
    def __init__(self):
        self.register_sample = 0
        self.sensor_sample = 0
        self.generation_reg = 0
        self.usage_reg = 0
        self.tesla_charger_reg = 0
        self.charge_rate_sensor = 0
        self.charger_voltage_sensor = 0
        self.new_charge_rate = 0

    def sample_register(self):
        from main import my_egauge
        self.register_sample = Register(my_egauge, {"rate": "True", "time": "now"})
        self.generation_reg = self.register_sample.pq_rate("gen").value*1000
        self.usage_reg = self.register_sample.pq_rate("use").value*1000
        self.tesla_charger_reg = self.register_sample.pq_rate("Tesla Charger").value*1000

    def sample_sensor(self):
        from main import my_egauge
        self.sensor_sample = Local(my_egauge, "l=L1:L2&s=all")
        self.charger_voltage_sensor = (self.sensor_sample.rate("L1", "n") +
                                       self.sensor_sample.rate("L2", "n"))
        self.charge_rate_sensor = self.sensor_sample.rate("S6", "n")

    def calculate_charge_rate(self, new_sample):
        if new_sample:
            self.sample_register()
            self.sample_sensor()
        # Calculate the charge rate
        self.new_charge_rate = ((self.generation_reg - (self.usage_reg - self.tesla_charger_reg)) /
                                self.charger_voltage_sensor)
        return self.new_charge_rate

    def verify_new_charge_rate(self, new_charge_rate):
        for attempts in range(0, 5):
            self.sample_sensor()
            # Use round() on the verify step (vs math.floor()) to prevent constant requests for the same value
            if round(self.charge_rate_sensor) >= new_charge_rate:
                return True
            sleep(0.5)

        return False

    def sufficient_generation(self, min_charge):
        charge_rate = math.floor(self.calculate_charge_rate(new_sample=True))
        #print("Charge rate:", charge_rate)
        if charge_rate >= min_charge:
            return True
        else:
            return False


class TeslaCommand:
    def __init__(self):
        self.tesla_base_command = [tesla_control_bin, '-ble', '-key-file', tesla_key_file]

    def set_charge_rate(self, charge_rate):
        command = self.tesla_base_command + ['charging-set-amps']
        command.append(str(charge_rate))
        print(command)
        return call_sub_error_handler(command)

    def start_charging(self):
        command = self.tesla_base_command + ['charging-start']
        print(command)
        return call_sub_error_handler(command)

    def stop_charging(self):
        command = self.tesla_base_command + ['charging-stop']
        print(command)
        return call_sub_error_handler(command)

    def wake(self):
        command = self.tesla_base_command + ['-domain', 'vcsec', 'wake']
        print(command)
        return call_sub_error_handler(command)

    def test_cmd(self):
        #command = ['lsR', '-la']
        command = self.tesla_base_command + ['honk']
        print(command)
        return call_sub_error_handler(command)


def call_sub_error_handler(cmd):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, check=True)
        print(p.stdout)
    except subprocess.CalledProcessError as error:
        print("An exception occurred:", type(error).__name__, "–", error)
        print(error.stderr)
        return False
    return True

